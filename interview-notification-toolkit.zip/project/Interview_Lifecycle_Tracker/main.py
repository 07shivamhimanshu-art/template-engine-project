"""
Interview_Lifecycle_Tracker/main.py

A small tkinter GUI for logging interview stage changes. Events are written
as structured JSON Lines to a data directory (configurable via
TRACKER_DATA_DIR), with error handling around the file write so a
permissions issue or full disk shows a dialog instead of crashing the app.

Optionally, on relevant stage transitions ("Completed" / "Incomplete"), it
can trigger a notification email via task5.py's /send_email endpoint. This
is off by default and fully non-blocking (the HTTP call runs on a background
thread) so the GUI never freezes while waiting on the network.
"""

import json
import os
import threading
import tkinter as tk
import urllib.error
import urllib.request
from datetime import datetime, timezone
from tkinter import messagebox, ttk

# --- Configuration -----------------------------------------------------

DATA_DIR = os.environ.get(
    "TRACKER_DATA_DIR",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "data"),
)
EVENTS_FILE = os.path.join(DATA_DIR, "events.jsonl")

NOTIFY_ENABLED = os.environ.get("TRACKER_NOTIFY_ENABLED", "false").strip().lower() in ("1", "true", "yes")
NOTIFY_URL = os.environ.get("TRACKER_NOTIFY_URL", "http://127.0.0.1:5000/send_email")
NOTIFY_API_KEY = os.environ.get("TRACKER_NOTIFY_API_KEY", "")

NOTIFY_STAGES = {"Completed", "Incomplete"}
STAGES = ["Scheduled", "In Progress", "Completed", "Incomplete", "Cancelled"]


# --- Persistence ---------------------------------------------------------

def ensure_data_dir():
    os.makedirs(DATA_DIR, exist_ok=True)


def log_event(candidate, stage, notes=""):
    """Append a structured event to the JSON Lines log.

    Returns True on success. On failure, shows a messagebox and returns
    False instead of letting the exception propagate out of a GUI callback.
    """
    event = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "candidate": candidate,
        "stage": stage,
        "notes": notes,
    }
    try:
        ensure_data_dir()
        with open(EVENTS_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(event) + "\n")
        return True
    except OSError as e:
        messagebox.showerror("Logging Error", f"Could not write event to log file:\n{e}")
        return False


# --- Notification integration --------------------------------------------

def notify_async(candidate, recipient):
    """Fire-and-forget call to task5.py's /send_email endpoint.

    Runs on a daemon thread so the GUI thread is never blocked on network
    I/O. Failures are logged to stdout rather than raised, since this is a
    best-effort notification, not the source of truth for tracking.
    """

    def _send():
        try:
            payload = json.dumps({"recipient": recipient, "candidate": candidate}).encode("utf-8")
            req = urllib.request.Request(
                NOTIFY_URL,
                data=payload,
                headers={
                    "Content-Type": "application/json",
                    "X-API-Key": NOTIFY_API_KEY,
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                if resp.status != 200:
                    print(f"[notify] Non-200 response ({resp.status}) notifying for {candidate}")
        except (urllib.error.URLError, urllib.error.HTTPError) as e:
            print(f"[notify] Failed to send notification for {candidate}: {e}")

    threading.Thread(target=_send, daemon=True).start()


# --- GUI -------------------------------------------------------------------

class InterviewTrackerApp:
    def __init__(self, root):
        self.root = root
        root.title("Interview Lifecycle Tracker")
        root.geometry("440x300")
        root.resizable(False, False)

        frm = ttk.Frame(root, padding=16)
        frm.pack(fill="both", expand=True)

        ttk.Label(frm, text="Candidate name").pack(anchor="w")
        self.candidate_var = tk.StringVar()
        ttk.Entry(frm, textvariable=self.candidate_var).pack(fill="x", pady=(0, 10))

        ttk.Label(frm, text="Recipient email (for notifications)").pack(anchor="w")
        self.recipient_var = tk.StringVar()
        ttk.Entry(frm, textvariable=self.recipient_var).pack(fill="x", pady=(0, 10))

        ttk.Label(frm, text="Stage").pack(anchor="w")
        self.stage_var = tk.StringVar(value=STAGES[0])
        ttk.Combobox(frm, textvariable=self.stage_var, values=STAGES, state="readonly").pack(fill="x", pady=(0, 10))

        ttk.Label(frm, text="Notes").pack(anchor="w")
        self.notes_var = tk.StringVar()
        ttk.Entry(frm, textvariable=self.notes_var).pack(fill="x", pady=(0, 16))

        ttk.Button(frm, text="Track Interview", command=self.track_interview).pack()

        status_text = "Notifications: enabled" if NOTIFY_ENABLED else "Notifications: disabled"
        status_color = "#1a7f37" if NOTIFY_ENABLED else "#666666"
        ttk.Label(frm, text=status_text, foreground=status_color).pack(pady=(14, 0))
        ttk.Label(frm, text=f"Log file: {EVENTS_FILE}", foreground="#888888").pack(pady=(2, 0))

    def track_interview(self):
        candidate = self.candidate_var.get().strip()
        stage = self.stage_var.get().strip()
        notes = self.notes_var.get().strip()
        recipient = self.recipient_var.get().strip()

        if not candidate:
            messagebox.showwarning("Missing info", "Please enter a candidate name.")
            return

        if not log_event(candidate, stage, notes):
            return  # error already shown to the user

        if NOTIFY_ENABLED and stage in NOTIFY_STAGES:
            if recipient:
                notify_async(candidate, recipient)
            else:
                messagebox.showwarning(
                    "Notification skipped",
                    "Notifications are enabled but no recipient email was provided.",
                )

        messagebox.showinfo("Tracked", f"Logged '{stage}' for {candidate}.")
        self.notes_var.set("")


def main():
    root = tk.Tk()
    InterviewTrackerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
