# Interview Notification Toolkit

Two small tools that work together as one interview-notification workflow:

- **`task5.py`** — a Flask service with a single `/send_email` endpoint that
  sends interview-status emails via SendGrid.
- **`Interview_Lifecycle_Tracker/main.py`** — a tkinter GUI for logging
  interview stage changes, with an optional (off by default) call into
  `task5.py` to trigger a real notification when a candidate is marked
  `Completed` or `Incomplete`.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# edit .env: set SENDGRID_API_KEY and APP_API_KEY at minimum
```

## Running the email service

```bash
python task5.py
```

By default this starts the Flask dev server with debug mode **off**. To run
with the interactive debugger for local development only:

```bash
FLASK_DEBUG=true python task5.py
```

Never set `FLASK_DEBUG=true` on a shared or production deployment — it
enables Werkzeug's interactive debugger, which allows arbitrary code
execution if the server is ever reachable beyond localhost. For anything
beyond local iteration, run behind a proper WSGI server such as gunicorn or
uwsgi, not Flask's built-in dev server.

### Endpoints

- `GET /` — health check, always returns `200 {"status": "ok"}`.
- `POST /send_email` — sends a notification email. Requires:
  - Header `X-API-Key: <APP_API_KEY>`
  - JSON body: `{"recipient": "someone@example.com", "candidate": "Jane Doe"}`

Responses now use accurate HTTP status codes instead of always returning
`200`:

| Situation                              | Status |
|-----------------------------------------|--------|
| Email sent successfully                 | 200    |
| Missing/invalid `recipient` or `candidate` | 400 |
| Missing/invalid API key                 | 401    |
| Rate limit exceeded                     | 429    |
| Server misconfiguration (no keys set)   | 500    |
| SendGrid call itself fails              | 502    |

Failure responses return a safe, generic message. The full exception detail
is logged server-side (via the standard `logging` module) but never sent to
the caller.

### Trust model

`/send_email` is a **thin internal service**, not a public-facing endpoint.
It sends real email through a paid SendGrid account, so anyone who can reach
it and knows (or guesses) the API key can consume that account's sending
quota. Treat it accordingly:

- Deploy it on an internal network / private subnet, not directly on the
  public internet.
- Set `APP_API_KEY` to a long random secret (see `.env.example`) and share it
  only with trusted internal callers (e.g. the tracker GUI, or another
  internal service).
- The built-in rate limiter (`RATE_LIMIT_MAX_REQUESTS` per
  `RATE_LIMIT_WINDOW_SECONDS`, per API key / IP) is in-memory and
  per-process. It bounds abuse from a single compromised or misbehaving
  caller on a single-worker deployment, but does **not** coordinate across
  multiple workers or replicas — back it with Redis (or similar) if you
  scale beyond one process.

## Running the tracker GUI

```bash
python Interview_Lifecycle_Tracker/main.py
```

Events are appended as structured JSON Lines to
`Interview_Lifecycle_Tracker/data/events.jsonl` (configurable via
`TRACKER_DATA_DIR`). Each line looks like:

```json
{"timestamp": "2026-07-18T10:15:00+00:00", "candidate": "Jane Doe", "stage": "Completed", "notes": ""}
```

If the log file can't be written (permissions, full disk, etc.), the GUI
shows an error dialog instead of crashing.

### Wiring it to email notifications

By default the tracker does **not** call `task5.py`. To enable it:

```bash
export TRACKER_NOTIFY_ENABLED=true
export TRACKER_NOTIFY_URL=http://127.0.0.1:5000/send_email
export TRACKER_NOTIFY_API_KEY=<same value as APP_API_KEY>
```

When enabled, marking a candidate `Completed` or `Incomplete` (with a
recipient email filled in) fires a background HTTP request to `/send_email`
on a daemon thread, so the GUI never blocks waiting on the network.

## Tests

```bash
pytest
```

`tests/test_task5.py` covers, against a mocked `SendGridAPIClient`:
- the health-check route,
- a successful send,
- missing/invalid `recipient`,
- missing `candidate`,
- a SendGrid exception (asserts a `502` and that no raw exception text
  leaks into the response),
- missing/incorrect API key,
- and the rate limiter tripping after the configured request count.

## Dependencies

`requirements.txt` is intentionally minimal and UTF-8 encoded, listing only
what this repo's code actually imports (`flask`, `python-dotenv`,
`sendgrid`) plus test tooling (`pytest`, `pytest-mock`). `tkinter` is part of
the Python standard library and isn't pip-installable — if it's missing on
your system, install your OS's `python3-tk` package (or equivalent).
