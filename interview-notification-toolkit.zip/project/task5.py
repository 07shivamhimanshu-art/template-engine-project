"""
task5.py - Email notification service.

Sends interview-status emails via SendGrid. Exposes a single POST endpoint,
/send_email, protected by a shared-secret API key and a simple in-memory
rate limiter, plus a GET / health-check route.

See README.md for setup, environment variables, and the documented trust
boundary for this service.
"""

import os
import re
import logging
from collections import defaultdict, deque
from functools import wraps
from time import time

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail

load_dotenv()

app = Flask(__name__)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("task5")

# --- Configuration -----------------------------------------------------

SENDGRID_API_KEY = os.environ.get("SENDGRID_API_KEY")
FROM_EMAIL = os.environ.get("FROM_EMAIL", "notifications@example.com")
API_KEY = os.environ.get("APP_API_KEY")  # shared-secret required on /send_email

RATE_LIMIT_WINDOW_SECONDS = int(os.environ.get("RATE_LIMIT_WINDOW_SECONDS", "60"))
RATE_LIMIT_MAX_REQUESTS = int(os.environ.get("RATE_LIMIT_MAX_REQUESTS", "10"))

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

# caller_id -> deque of request timestamps within the current window.
# NOTE: this is per-process, in-memory rate limiting. It's sufficient for a
# single dev/staging instance behind one worker, but will NOT coordinate
# across multiple gunicorn/uwsgi workers or replicas. For a multi-worker
# production deployment, back this with Redis or a similar shared store.
_rate_limit_buckets = defaultdict(deque)


# --- Helpers -------------------------------------------------------------

def is_valid_email(value):
    return bool(value) and bool(EMAIL_RE.match(value.strip()))


def require_api_key(view_func):
    """Require a matching X-API-Key header.

    This is a minimum-viable auth mechanism intended for a trusted internal
    caller (e.g. the Interview_Lifecycle_Tracker GUI or another internal
    service) -- see README.md's "Trust model" section. It is not intended
    to make this endpoint safe to expose directly on the public internet.
    """

    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if not API_KEY:
            logger.error("APP_API_KEY is not configured; refusing all requests to protected endpoint.")
            return jsonify({"status": "failed", "error": "Server auth is not configured."}), 500
        provided = request.headers.get("X-API-Key")
        if not provided or provided != API_KEY:
            return jsonify({"status": "failed", "error": "Unauthorized."}), 401
        return view_func(*args, **kwargs)

    return wrapped


def rate_limited(view_func):
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        caller_id = request.headers.get("X-API-Key") or request.remote_addr or "unknown"
        now = time()
        bucket = _rate_limit_buckets[caller_id]
        while bucket and now - bucket[0] > RATE_LIMIT_WINDOW_SECONDS:
            bucket.popleft()
        if len(bucket) >= RATE_LIMIT_MAX_REQUESTS:
            return jsonify({"status": "failed", "error": "Rate limit exceeded. Try again later."}), 429
        bucket.append(now)
        return view_func(*args, **kwargs)

    return wrapped


# --- Routes ----------------------------------------------------------------

@app.route("/", methods=["GET"])
def health_check():
    return jsonify({"status": "ok"}), 200


@app.route("/send_email", methods=["POST"])
@require_api_key
@rate_limited
def send_email():
    data = request.get_json(silent=True) or {}
    recipient = (data.get("recipient") or "").strip()
    candidate = (data.get("candidate") or "").strip()

    if not recipient or not is_valid_email(recipient):
        return jsonify({"status": "failed", "error": "A valid 'recipient' email address is required."}), 400

    if not candidate:
        return jsonify({"status": "failed", "error": "'candidate' is required."}), 400

    if not SENDGRID_API_KEY:
        logger.error("SENDGRID_API_KEY is not configured.")
        return jsonify({"status": "failed", "error": "Email service is not configured."}), 500

    try:
        html_content = render_template("email_template.html", candidate=candidate)
    except Exception:
        logger.exception("Failed to render email template for candidate=%s", candidate)
        return jsonify({"status": "failed", "error": "Failed to prepare email content."}), 500

    message = Mail(
        from_email=FROM_EMAIL,
        to_emails=recipient,
        subject=f"Interview Update for {candidate}",
        html_content=html_content,
    )

    try:
        sg = SendGridAPIClient(SENDGRID_API_KEY)
        response = sg.send(message)
        logger.info(
            "Email sent to %s (candidate=%s) sendgrid_status=%s",
            recipient,
            candidate,
            getattr(response, "status_code", "unknown"),
        )
        return jsonify({"status": "sent", "recipient": recipient}), 200
    except Exception:
        # Log full internal detail server-side; never leak it to the caller.
        logger.exception("SendGrid send failed for recipient=%s candidate=%s", recipient, candidate)
        return (
            jsonify(
                {
                    "status": "failed",
                    "error": "Failed to send email. Please try again later or contact an administrator.",
                }
            ),
            502,
        )


if __name__ == "__main__":
    debug_mode = os.environ.get("FLASK_DEBUG", "false").strip().lower() in ("1", "true", "yes")
    app.run(debug=debug_mode)
