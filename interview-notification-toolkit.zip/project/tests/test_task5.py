import os
import sys

import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Configure env vars before importing the app module.
os.environ.setdefault("APP_API_KEY", "test-key")
os.environ.setdefault("SENDGRID_API_KEY", "test-sendgrid-key")
os.environ.setdefault("FROM_EMAIL", "test@example.com")

import task5  # noqa: E402

AUTH_HEADERS = {"X-API-Key": "test-key"}


@pytest.fixture
def client():
    task5.app.config["TESTING"] = True
    with task5.app.test_client() as c:
        yield c


@pytest.fixture(autouse=True)
def _reset_rate_limit_buckets():
    task5._rate_limit_buckets.clear()
    yield
    task5._rate_limit_buckets.clear()


def test_health_check(client):
    resp = client.get("/")
    assert resp.status_code == 200
    assert resp.get_json()["status"] == "ok"


def test_send_email_success(client, mocker):
    mock_response = mocker.Mock(status_code=202)
    mocker.patch.object(task5.SendGridAPIClient, "send", return_value=mock_response)

    resp = client.post(
        "/send_email",
        json={"recipient": "candidate@example.com", "candidate": "Jane Doe"},
        headers=AUTH_HEADERS,
    )

    assert resp.status_code == 200
    body = resp.get_json()
    assert body["status"] == "sent"
    assert body["recipient"] == "candidate@example.com"


def test_send_email_missing_recipient(client):
    resp = client.post(
        "/send_email",
        json={"candidate": "Jane Doe"},
        headers=AUTH_HEADERS,
    )
    assert resp.status_code == 400
    assert resp.get_json()["status"] == "failed"


def test_send_email_invalid_recipient_format(client):
    resp = client.post(
        "/send_email",
        json={"recipient": "not-an-email", "candidate": "Jane Doe"},
        headers=AUTH_HEADERS,
    )
    assert resp.status_code == 400


def test_send_email_missing_candidate(client):
    resp = client.post(
        "/send_email",
        json={"recipient": "candidate@example.com"},
        headers=AUTH_HEADERS,
    )
    assert resp.status_code == 400
    assert resp.get_json()["status"] == "failed"


def test_send_email_sendgrid_exception_returns_502_and_hides_internals(client, mocker):
    mocker.patch.object(
        task5.SendGridAPIClient,
        "send",
        side_effect=Exception("raw internal sendgrid detail: bad api key XYZ"),
    )

    resp = client.post(
        "/send_email",
        json={"recipient": "candidate@example.com", "candidate": "Jane Doe"},
        headers=AUTH_HEADERS,
    )

    assert resp.status_code == 502
    body = resp.get_json()
    assert body["status"] == "failed"
    assert "raw internal sendgrid detail" not in body["error"]
    assert "XYZ" not in body["error"]


def test_send_email_requires_auth(client):
    resp = client.post(
        "/send_email",
        json={"recipient": "candidate@example.com", "candidate": "Jane Doe"},
    )
    assert resp.status_code == 401


def test_send_email_rejects_wrong_key(client):
    resp = client.post(
        "/send_email",
        json={"recipient": "candidate@example.com", "candidate": "Jane Doe"},
        headers={"X-API-Key": "wrong-key"},
    )
    assert resp.status_code == 401


def test_send_email_rate_limit(client, mocker):
    mock_response = mocker.Mock(status_code=202)
    mocker.patch.object(task5.SendGridAPIClient, "send", return_value=mock_response)

    original_max = task5.RATE_LIMIT_MAX_REQUESTS
    task5.RATE_LIMIT_MAX_REQUESTS = 2
    try:
        for _ in range(2):
            resp = client.post(
                "/send_email",
                json={"recipient": "candidate@example.com", "candidate": "Jane Doe"},
                headers=AUTH_HEADERS,
            )
            assert resp.status_code == 200

        resp = client.post(
            "/send_email",
            json={"recipient": "candidate@example.com", "candidate": "Jane Doe"},
            headers=AUTH_HEADERS,
        )
        assert resp.status_code == 429
    finally:
        task5.RATE_LIMIT_MAX_REQUESTS = original_max
