# Changelog — Issue Fixes

All 8 open issues from the review have been addressed in this update.

---

### ISSUE-20 — README sample output did not match actual code output
**Fix:** README's "Sample Output" section is now a verbatim excerpt captured by
actually running `main.py`, instead of a hand-written/aspirational example.
Feature list, project structure, and channel docs were also brought in line
with the real code (`channels.py`, `exceptions.py`, `.html` templates).

### ISSUE-21 — locale/event interpolated directly into a filesystem path
**Fix:** `template_loader.py` now validates `locale` and `event` against a
strict `^[a-zA-Z0-9_]+$` identifier pattern *before* they are ever used to
build a path (rejects `..`, `/`, null bytes, etc.). As defense in depth, the
resolved absolute path is also checked with `os.path.commonpath()` to confirm
it stays inside the `templates/` directory. Added regression tests
(`test_locale_path_traversal_rejected`, `test_event_path_traversal_rejected`,
`test_event_with_null_byte_rejected`).

### ISSUE-22 — send_notification crashed with an unhandled KeyError
**Fix:** The rendering engine (`notification_service.render_template`) no
longer lets a `KeyError` escape. Missing placeholder values are collected and
raised as a dedicated `exceptions.MissingDataError` (subclass of `ValueError`),
which `main.py`'s existing `except Exception` already handles gracefully.
Added `test_missing_data_never_raises_bare_key_error` as a regression test.

### ISSUE-23 — Placeholder substitution used sequential str.replace()
**Fix:** Rewrote `render_template()` to do a single `re.sub()` pass over the
template with a lookup callback, instead of looping through every discovered
placeholder and calling `str.replace()` once each. This is a genuine
templating-engine approach (one scan, one substitution pass, pluggable
escaping) rather than repeated whole-string scans, and it also naturally
supports HTML-escaping values per channel.

### ISSUE-24 — No validation that a User's locale is supported at creation
**Fix:** `users.py` now explicitly checks `locale` against
`User.SUPPORTED_LOCALES` at construction time. Falling back to English is
still the default behaviour, but it's logged via `logging.warning(...)`
instead of happening silently. A new `strict_locale=True` constructor flag
lets callers opt into a hard `ValueError` for unsupported locales instead.

### ISSUE-25 — No automated tests despite README claiming they were run
**Fix:** `test_notification.py` was expanded from the original set to 26
test cases, covering every fix above plus the pre-existing behaviour
(multi-locale rendering, fallback, missing data, unicode, invalid users/
emails, all events). Tests run with zero network access (channels use
`dry_run=True`), so `python -m unittest test_notification.py` is fully
self-contained and reproducible — matching what the README now claims.

### ISSUE-26 — Notification delivery was print-only despite the project's naming
**Fix:** Added `channels.py` with a `NotificationChannel` interface and three
implementations: `ConsoleChannel` (keeps the old print behaviour),
`EmailChannel` (real SMTP dispatch via `smtplib`, with a safe `dry_run`
default so the project still runs without credentials), and `SMSChannel`
(pluggable gateway function, same dry-run default). `send_notification()`
now accepts an optional `channel` argument and actually dispatches through
it. `main.py` was updated to use `ConsoleChannel` explicitly to demonstrate
the new dispatch path.

### ISSUE-27 — Template files were plain text with no structure for HTML channels
**Fix:** Added an `.html` template variant for every locale/event combination
(12 new files under `templates/<locale>/<event>.html`), each with a minimal,
valid HTML document structure. `template_loader.load_template()` now accepts
a `channel` parameter (`"text"`, `"email"`, `"sms"`) that selects the correct
file extension, and `EmailChannel` renders through the HTML variant with
values HTML-escaped to prevent markup/script injection.
