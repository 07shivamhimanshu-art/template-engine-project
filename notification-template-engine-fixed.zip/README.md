# Multi-Language Notification Template Engine

## Overview

This project implements a multilingual notification template engine in Python. Notifications are generated according to each user's preferred language (locale). The system loads language-specific templates, renders placeholders dynamically, and dispatches personalized notifications through a delivery channel (console, email, or SMS).

The application currently supports:

- English (en)
- Hindi (hi)
- Telugu (te)

It also supports multiple notification events such as interview scheduling, reminders, cancellations, and completion notifications.

---

# Features

- Multi-language notification templates (plain text and HTML)
- Locale-based template loading, with path-safe locale/event validation
- Explicit, logged English fallback for unsupported locales
- Single-pass placeholder rendering engine (no repeated `str.replace()` scanning)
- Real delivery channels: console, email (SMTP), SMS (pluggable gateway)
- Multiple notification events
- Input validation
- Exception handling with dedicated exception types
- Template validation
- Logging support
- Unicode support
- Automated unit tests (26 test cases)

---

# Supported Notification Events

- interview_scheduled
- interview_reminder
- interview_cancelled
- interview_completed

---

# Supported Placeholders

Templates can contain the following placeholders:

- `{{name}}`
- `{{date}}`
- `{{time}}`

These placeholders are replaced automatically, in a single pass, while generating notifications. When rendering for the email channel, values are HTML-escaped to prevent markup/script injection via user-supplied data.

---

# Delivery Channels

Notifications are rendered and then handed to a `NotificationChannel`:

| Channel         | Template used        | Behaviour                                                                 |
|-----------------|-----------------------|----------------------------------------------------------------------------|
| `ConsoleChannel`| `.txt`                | Prints the notification to stdout (used by `main.py`)                     |
| `EmailChannel`  | `.html`                | Sends via SMTP when configured; otherwise logs a dry run (default)        |
| `SMSChannel`    | `.txt`                | Sends via an injected gateway function when configured; otherwise dry run |

By default, `EmailChannel` and `SMSChannel` run in `dry_run=True` mode so the project runs out of the box without real credentials. Supplying SMTP credentials (or an SMS `send_fn`) switches them to real delivery.

```python
from channels import EmailChannel
from notification_service import send_notification

channel = EmailChannel(
    smtp_host="smtp.example.com",
    username="user",
    password="secret",
    dry_run=False,
)

send_notification(user, "interview_scheduled", data, channel=channel)
```

---

# Project Structure

```
notification-template-engine/
│
├── templates/
│   ├── en/
│   │   ├── interview_scheduled.txt
│   │   ├── interview_scheduled.html
│   │   ├── interview_reminder.txt
│   │   ├── interview_reminder.html
│   │   ├── interview_cancelled.txt
│   │   ├── interview_cancelled.html
│   │   ├── interview_completed.txt
│   │   └── interview_completed.html
│   │
│   ├── hi/  (same file set as en/)
│   └── te/  (same file set as en/)
│
├── users.py               # User model + locale validation
├── template_loader.py     # Path-safe template loading + validation
├── notification_service.py# Rendering engine + send_notification()
├── channels.py             # ConsoleChannel / EmailChannel / SMSChannel
├── exceptions.py            # MissingDataError, TemplateRenderError, etc.
├── main.py
├── test_notification.py
├── CHANGELOG.md
└── README.md
```

---

# Technologies Used

- Python 3
- `smtplib` / `email` (email dispatch)
- `os` / `re` module (path-safe template loading)
- `logging` module
- `unittest`
- Git
- GitHub

---

# Running the Project

Clone the repository

```
git clone <repository-url>
```

Move to the project directory

```
cd notification-template-engine
```

Run the application

```
python main.py
```

Run unit tests

```
python -m unittest test_notification.py -v
```

---

# Sample Output

Running `python main.py` prints the actual, current output below (log lines go to stderr and are omitted for clarity). This is a verbatim excerpt — it is regenerated from the live code, not hand-written, so it won't drift from what the code actually produces:

```
============================================================
EVENT : INTERVIEW_SCHEDULED
============================================================

[CONSOLE] To: vaish@gmail.com
Subject: Interview Scheduled
Hello Vaishnavi,

Your interview has been scheduled.

Date: 10 July

Time: 5 PM

Thank you,
Interview Team

[CONSOLE] To: jaya@gmail.com
Subject: Interview Scheduled
नमस्ते Jaya,

आपका इंटरव्यू निर्धारित किया गया है।

दिनांक: 10 July

समय: 5 PM

धन्यवाद,
इंटरव्यू टीम

[CONSOLE] To: anushka@gmail.com
Subject: Interview Scheduled
హలో Anushka,

మీ ఇంటర్వ్యూ షెడ్యూల్ చేయబడింది.

తేదీ: 10 July

సమయం: 5 PM

ధన్యవాదాలు,
ఇంటర్వ్యూ టీమ్
```

The remaining events (`interview_reminder`, `interview_cancelled`, `interview_completed`) follow the same pattern for each locale.

---

# Error Handling

The project validates:

- Invalid user details
- Invalid email addresses
- Locale values, with explicit logged fallback to English (or a hard error via `strict_locale=True`)
- Path-safe locale/event identifiers (rejects path traversal attempts before touching the filesystem)
- Empty templates
- Missing template files
- Invalid placeholders
- Invalid notification events
- Missing notification data (raises `MissingDataError`/`ValueError`, never a raw `KeyError`)
- Delivery failures (`channels.DeliveryError`)

---

# Logging

The system records important events including:

- Template loading
- Locale fallback
- Notification generation
- File loading errors
- Delivery attempts (dry-run and real)

---

# Testing

`test_notification.py` contains 26 automated test cases covering: multi-locale rendering, locale fallback, the single-pass templating engine, HTML escaping, path-traversal rejection, missing-data handling, HTML/email template loading, and all three delivery channels (using dry-run mode so tests never require real network access).

---

# Future Enhancements

- Database-backed user/locale registry
- Automatic language discovery
- Jinja2 template engine support for richer templates
- REST API integration
- Phone number field on `User` for real SMS delivery

---

# Author

**Vaishnavi Jagdale**
