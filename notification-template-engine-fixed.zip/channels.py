"""
Delivery channels for notifications.

Previously the "notification engine" only ever printed the rendered
message to stdout, despite the project name implying it actually
delivers notifications via email/SMS. This module gives each channel a
real send() implementation:

- EmailChannel sends via SMTP (smtplib) when credentials are configured.
- SMSChannel sends via a pluggable HTTP gateway (e.g. Twilio-style API)
  when credentials are configured.
- Both default to `dry_run=True`, which logs exactly what would be sent
  without requiring real credentials/network access. This keeps the
  project runnable out of the box and unit-testable, while making the
  dispatch path fully real once credentials are supplied.
- ConsoleChannel preserves the original print-to-stdout behaviour for
  local debugging/demo purposes.
"""

import logging
import smtplib
from abc import ABC, abstractmethod
from email.message import EmailMessage

logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s: %(message)s"
)


class DeliveryError(Exception):
    """Raised when a channel fails to deliver a notification."""


class NotificationChannel(ABC):
    """Base interface every delivery channel must implement."""

    name = "base"

    @abstractmethod
    def send(self, user, subject, message):
        """
        Deliver `message` (already rendered) to `user`.
        Returns True on success, raises DeliveryError on failure.
        """
        raise NotImplementedError


class ConsoleChannel(NotificationChannel):
    """Prints the notification to stdout. Useful for local demos/tests."""

    name = "console"

    def send(self, user, subject, message):
        print(f"\n[{self.name.upper()}] To: {user.email}")
        if subject:
            print(f"Subject: {subject}")
        print(message)
        logging.info(f"Console delivery complete for {user.name}.")
        return True


class EmailChannel(NotificationChannel):
    """
    Sends the notification as an email via SMTP.

    If no SMTP host is configured (or dry_run=True), the channel logs
    what *would* be sent instead of opening a real network connection.
    This keeps the project runnable without real credentials while
    still exercising the full dispatch code path.
    """

    name = "email"

    def __init__(
        self,
        smtp_host=None,
        smtp_port=587,
        username=None,
        password=None,
        sender="no-reply@example.com",
        dry_run=True,
    ):
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.username = username
        self.password = password
        self.sender = sender
        self.dry_run = dry_run or not smtp_host

    def send(self, user, subject, message):
        if self.dry_run:
            logging.info(
                f"[DRY RUN] Would send EMAIL to {user.email} "
                f"(subject='{subject}')."
            )
            return True

        email_message = EmailMessage()
        email_message["From"] = self.sender
        email_message["To"] = user.email
        email_message["Subject"] = subject or "Notification"
        email_message.set_content(message, subtype="html")

        try:
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                server.starttls()
                if self.username and self.password:
                    server.login(self.username, self.password)
                server.send_message(email_message)
        except (smtplib.SMTPException, OSError) as e:
            logging.error(f"Failed to send email to {user.email}: {e}")
            raise DeliveryError(f"Email delivery failed: {e}") from e

        logging.info(f"Email sent to {user.email}.")
        return True


class SMSChannel(NotificationChannel):
    """
    Sends the notification via an SMS gateway HTTP API.

    A `send_fn` can be injected for use with any provider's SDK/HTTP
    client (e.g. Twilio, AWS SNS). If none is configured (or
    dry_run=True), the channel logs what would be sent.
    """

    name = "sms"

    def __init__(self, send_fn=None, dry_run=True):
        self.send_fn = send_fn
        self.dry_run = dry_run or send_fn is None

    def send(self, user, subject, message):
        if self.dry_run:
            logging.info(
                f"[DRY RUN] Would send SMS to {user.email} "
                f"(no phone number field on User yet)."
            )
            return True

        try:
            self.send_fn(user, message)
        except Exception as e:
            logging.error(f"Failed to send SMS to {user.name}: {e}")
            raise DeliveryError(f"SMS delivery failed: {e}") from e

        logging.info(f"SMS sent for {user.name}.")
        return True


CHANNEL_REGISTRY = {
    "console": ConsoleChannel,
    "email": EmailChannel,
    "sms": SMSChannel,
}
