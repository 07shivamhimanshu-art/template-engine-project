class NotificationError(Exception):
    """Base class for all notification-engine specific errors."""


class MissingDataError(NotificationError):
    """
    Raised when data required to render a notification is missing.

    Replaces the previously unhandled KeyError that could bubble up
    from render_template() when a template referenced a placeholder
    that wasn't present in the supplied data.
    """


class TemplateRenderError(NotificationError):
    """Raised when a template cannot be rendered for any other reason."""
