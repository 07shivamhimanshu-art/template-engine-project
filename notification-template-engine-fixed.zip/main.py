from users import User
from notification_service import send_notification
from channels import ConsoleChannel, EmailChannel


def main():

    users = [

        User(
            "Vaishnavi",
            "vaish@gmail.com",
            "en"
        ),

        User(
            "Jaya",
            "jaya@gmail.com",
            "hi"
        ),

        User(
            "Anushka",
            "anushka@gmail.com",
            "te"
        )
    ]

    # Different notification events
    events = [

        "interview_scheduled",
        "interview_reminder",
        "interview_cancelled",
        "interview_completed"

    ]

    data = {

        "date": "10 July",
        "time": "5 PM"

    }

    # ConsoleChannel prints notifications, matching the previous
    # print-only behaviour. Swap this for EmailChannel(...) with real
    # SMTP credentials (dry_run=False) to actually deliver email.
    channel = ConsoleChannel()

    for event in events:

        print("\n")
        print("=" * 60)
        print(f"EVENT : {event.upper()}")
        print("=" * 60)

        for user in users:

            try:

                send_notification(
                    user,
                    event,
                    data,
                    channel=channel,
                )

            except Exception as e:

                print(
                    f"Error sending notification "
                    f"to {user.name}: {e}"
                )


if __name__ == "__main__":
    main()
