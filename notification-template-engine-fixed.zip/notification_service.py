import html
import logging
import re

from template_loader import load_template
from exceptions import MissingDataError
from channels import ConsoleChannel

logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s: %(message)s"
)

# Maps a delivery channel name to the template variant it needs and
# whether interpolated values should be HTML-escaped.
_CHANNEL_TEMPLATE_TYPE = {
    "console": ("text", False),
    "sms": ("text", False),
    "email": ("email", True),
}

_PLACEHOLDER_PATTERN = re.compile(r"\{\{\s*(\w+)\s*\}\}")


def render_template(template, values, escape=False):
    """
    Renders a template in a single pass using a proper substitution
    engine (re.sub with a lookup callback) instead of iterating and
    calling str.replace() once per placeholder. This is both more
    efficient (one scan of the template instead of one scan per
    placeholder) and safer, since every placeholder is resolved through
    one consistent code path.

    Raises MissingDataError (instead of an unhandled KeyError) if the
    template references a placeholder that isn't present in `values`.
    """

    missing = []

    def _lookup(match):
        key = match.group(1)

        if key not in values or values[key] is None:
            missing.append(key)
            return match.group(0)

        value = str(values[key])
        return html.escape(value) if escape else value

    rendered = _PLACEHOLDER_PATTERN.sub(_lookup, template)

    if missing:
        raise MissingDataError(
            f"Missing value(s) for placeholder(s): {sorted(set(missing))}"
        )

    return rendered


def send_notification(user, event, data, channel=None):
    """
    Generates a localized notification and, if a delivery channel is
    provided, actually dispatches it (email/SMS/console) instead of
    only ever printing the rendered text.

    Args:
        user: A users.User instance.
        event: Notification event name, e.g. "interview_scheduled".
        data: Dict with the dynamic values for the template
            (currently "date" and "time"; "name" is taken from `user`).
        channel: Optional channels.NotificationChannel instance to
            dispatch through. If omitted, the message is only rendered
            and returned (backwards compatible with earlier behaviour).

    Returns:
        The rendered notification message (str).
    """

    if user is None:
        raise ValueError("User cannot be None.")

    if not isinstance(data, dict):
        raise ValueError("Notification data must be a dictionary.")

    channel_name = channel.name if channel else "console"
    template_type, should_escape = _CHANNEL_TEMPLATE_TYPE.get(
        channel_name, ("text", False)
    )

    template = load_template(
        user.locale,
        event,
        channel=template_type,
    )

    values = {
        "name": user.name,
        "date": data.get("date"),
        "time": data.get("time"),
    }

    if values["date"] is None:
        raise ValueError("Date is required.")

    if values["time"] is None:
        raise ValueError("Time is required.")

    message = render_template(
        template,
        values,
        escape=should_escape,
    )

    logging.info(
        f"Notification generated for {user.name}"
    )

    if channel is not None:
        subject = event.replace("_", " ").title()
        channel.send(user, subject, message)

    return message
