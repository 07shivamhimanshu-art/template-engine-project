import os
import logging
import re

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s: %(message)s"
)

# Base directory templates are loaded from. Resolved to an absolute path
# so every loaded file can be verified to stay inside it.
TEMPLATES_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "templates")
)

# Only simple, predictable identifiers are allowed for locale/event names.
# This is what actually prevents path traversal / injection: values are
# validated *before* they ever touch os.path.join, instead of trying to
# sanitize a path after the fact.
_SAFE_IDENTIFIER = re.compile(r"^[a-zA-Z0-9_]+$")

DEFAULT_LOCALE = "en"

# Supported delivery channels and the template file extension each one uses.
CHANNEL_EXTENSIONS = {
    "text": "txt",
    "email": "html",
    "sms": "txt",
}

# Supported placeholders
VALID_PLACEHOLDERS = {
    "{{name}}",
    "{{date}}",
    "{{time}}"
}


class InvalidTemplateError(ValueError):
    """Raised when a template fails validation."""


def _validate_identifier(value, label):
    """
    Ensures locale/event values are simple identifiers before they are
    used to build a filesystem path. Rejects anything containing path
    separators, '..', or other characters that could be used to escape
    the templates directory.
    """

    if not value or not isinstance(value, str):
        raise ValueError(f"Invalid {label}.")

    if not _SAFE_IDENTIFIER.match(value):
        raise ValueError(
            f"Invalid {label} '{value}'. Only letters, numbers and "
            f"underscores are allowed."
        )

    return value


def _resolve_template_path(locale, event, channel):
    """
    Builds and validates the on-disk path for a given locale/event/channel,
    guaranteeing the resolved path stays inside TEMPLATES_ROOT.
    """

    extension = CHANNEL_EXTENSIONS.get(channel)
    if extension is None:
        raise ValueError(
            f"Unsupported channel '{channel}'. Supported channels are: "
            f"{sorted(CHANNEL_EXTENSIONS)}"
        )

    candidate = os.path.abspath(
        os.path.join(TEMPLATES_ROOT, locale, f"{event}.{extension}")
    )

    # Defense in depth: even though locale/event are already restricted to
    # safe identifiers, double check the resolved path never escapes the
    # templates directory.
    if os.path.commonpath([TEMPLATES_ROOT, candidate]) != TEMPLATES_ROOT:
        raise ValueError("Resolved template path is outside templates directory.")

    return candidate


def validate_template(template):
    """
    Validate template content.
    """

    # Empty template
    if not template.strip():
        raise InvalidTemplateError("Template is empty.")

    # Find placeholders
    placeholders = set(
        re.findall(r"\{\{.*?\}\}", template)
    )

    # Invalid placeholder detection
    invalid = placeholders - VALID_PLACEHOLDERS

    if invalid:
        raise InvalidTemplateError(
            f"Invalid placeholders found: {invalid}"
        )

    return True


def load_template(locale, event, channel="text"):
    """
    Loads the notification template for the given locale, event and
    delivery channel ("text", "email" -> HTML, "sms").

    Falls back to English if the locale does not exist. locale and event
    are validated as safe identifiers before being used to build a
    filesystem path, preventing path traversal via crafted values.
    """

    locale = _validate_identifier(locale, "locale")
    event = _validate_identifier(event, "event name")

    file_path = _resolve_template_path(locale, event, channel)

    # Locale fallback
    if not os.path.exists(file_path):

        logging.warning(
            f"Locale '{locale}' not found. Falling back to "
            f"'{DEFAULT_LOCALE}'."
        )

        file_path = _resolve_template_path(DEFAULT_LOCALE, event, channel)

    # Event validation
    if not os.path.exists(file_path):
        raise FileNotFoundError(
            f"Template not found for event '{event}' (channel='{channel}')."
        )

    try:

        with open(
            file_path,
            "r",
            encoding="utf-8"
        ) as file:

            template = file.read()

    except OSError as e:

        logging.error(
            f"Unable to read template: {e}"
        )
        raise

    # Validate template
    validate_template(template)

    logging.info(
        f"Loaded template: {file_path}"
    )

    return template
