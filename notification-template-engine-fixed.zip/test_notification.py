import unittest

from users import User
from notification_service import send_notification, render_template
from template_loader import load_template
from exceptions import MissingDataError
from channels import ConsoleChannel, EmailChannel, SMSChannel


class TestNotificationSystem(unittest.TestCase):

    def setUp(self):

        self.data = {
            "date": "10 July",
            "time": "5 PM"
        }

        self.events = [
            "interview_scheduled",
            "interview_reminder",
            "interview_cancelled",
            "interview_completed"
        ]

    # --------------------------
    # Valid Notification Tests
    # --------------------------

    def test_english_notification(self):

        user = User("Vaishnavi", "vaish@gmail.com", "en")

        message = send_notification(
            user,
            "interview_scheduled",
            self.data
        )

        self.assertIn("Hello Vaishnavi", message)

    def test_hindi_notification(self):

        user = User("Jaya", "jaya@gmail.com", "hi")

        message = send_notification(
            user,
            "interview_scheduled",
            self.data
        )

        self.assertIn("नमस्ते Jaya", message)

    def test_telugu_notification(self):

        user = User("Anushka", "anu@gmail.com", "te")

        message = send_notification(
            user,
            "interview_scheduled",
            self.data
        )

        self.assertIn("హలో Anushka", message)

    # --------------------------
    # Locale Fallback
    # --------------------------

    def test_locale_fallback(self):

        user = User(
            "Alex",
            "alex@gmail.com",
            "fr"
        )

        # User() falls back to "en" at creation time already.
        self.assertEqual(user.locale, "en")

        message = send_notification(
            user,
            "interview_scheduled",
            self.data
        )

        self.assertIn("Hello Alex", message)

    def test_strict_locale_raises(self):

        with self.assertRaises(ValueError):
            User(
                "Alex",
                "alex@gmail.com",
                "fr",
                strict_locale=True,
            )

    # --------------------------
    # Placeholder Replacement / Templating engine
    # --------------------------

    def test_placeholder_replacement(self):

        user = User(
            "Vaishnavi",
            "vaish@gmail.com",
            "en"
        )

        message = send_notification(
            user,
            "interview_scheduled",
            self.data
        )

        self.assertIn("10 July", message)
        self.assertIn("5 PM", message)

    def test_render_template_single_pass_repeated_placeholder(self):

        template = "{{name}} - {{name}} - {{date}}"
        result = render_template(
            template,
            {"name": "Sam", "date": "1 Jan"},
        )
        self.assertEqual(result, "Sam - Sam - 1 Jan")

    def test_render_template_missing_value_raises_missing_data_error(self):

        with self.assertRaises(MissingDataError):
            render_template("Hello {{name}}", {})

    def test_render_template_html_escapes_values(self):

        template = "Hello {{name}}"
        result = render_template(
            template,
            {"name": "<script>alert(1)</script>"},
            escape=True,
        )
        self.assertNotIn("<script>", result)
        self.assertIn("&lt;script&gt;", result)

    # --------------------------
    # Invalid Event
    # --------------------------

    def test_invalid_event(self):

        user = User(
            "Vaishnavi",
            "vaish@gmail.com",
            "en"
        )

        with self.assertRaises(FileNotFoundError):

            send_notification(
                user,
                "random_event",
                self.data
            )

    # --------------------------
    # Path traversal protection
    # --------------------------

    def test_locale_path_traversal_rejected(self):

        with self.assertRaises(ValueError):
            load_template("../../../etc", "interview_scheduled")

    def test_event_path_traversal_rejected(self):

        with self.assertRaises(ValueError):
            load_template("en", "../../../etc/passwd")

    def test_event_with_null_byte_rejected(self):

        with self.assertRaises(ValueError):
            load_template("en", "interview_scheduled\x00.txt")

    # --------------------------
    # Missing Date / Time -> no unhandled KeyError
    # --------------------------

    def test_missing_date(self):

        user = User(
            "Vaishnavi",
            "vaish@gmail.com",
            "en"
        )

        with self.assertRaises(ValueError):

            send_notification(
                user,
                "interview_scheduled",
                {
                    "time": "5 PM"
                }
            )

    def test_missing_time(self):

        user = User(
            "Vaishnavi",
            "vaish@gmail.com",
            "en"
        )

        with self.assertRaises(ValueError):

            send_notification(
                user,
                "interview_scheduled",
                {
                    "date": "10 July"
                }
            )

    def test_missing_data_never_raises_bare_key_error(self):
        """
        Regression test: send_notification must never crash with a raw,
        unhandled KeyError. Any missing-data condition should surface as
        a ValueError/MissingDataError instead.
        """

        user = User("Vaishnavi", "vaish@gmail.com", "en")

        try:
            send_notification(user, "interview_scheduled", {})
        except KeyError:
            self.fail("send_notification leaked a raw KeyError")
        except (ValueError, MissingDataError):
            pass

    # --------------------------
    # Invalid User
    # --------------------------

    def test_invalid_user(self):

        with self.assertRaises(ValueError):

            User(
                "",
                "abc@gmail.com",
                "en"
            )

    # --------------------------
    # Invalid Email
    # --------------------------

    def test_invalid_email(self):

        with self.assertRaises(ValueError):

            User(
                "Vaishnavi",
                "wrongemail",
                "en"
            )

    # --------------------------
    # Unicode Handling
    # --------------------------

    def test_unicode_name(self):

        user = User(
            "वैष्णवी",
            "abc@gmail.com",
            "hi"
        )

        message = send_notification(
            user,
            "interview_scheduled",
            self.data
        )

        self.assertIn("वैष्णवी", message)

    # --------------------------
    # Multiple Events
    # --------------------------

    def test_all_events(self):

        user = User(
            "Vaishnavi",
            "abc@gmail.com",
            "en"
        )

        for event in self.events:

            message = send_notification(
                user,
                event,
                self.data
            )

            self.assertIsInstance(message, str)

    # --------------------------
    # Exception Handling
    # --------------------------

    def test_none_user(self):

        with self.assertRaises(ValueError):

            send_notification(
                None,
                "interview_scheduled",
                self.data
            )

    # --------------------------
    # HTML templates (email channel)
    # --------------------------

    def test_html_template_loaded_for_email_channel(self):

        user = User("Vaishnavi", "vaish@gmail.com", "en")
        channel = EmailChannel(dry_run=True)

        message = send_notification(
            user,
            "interview_scheduled",
            self.data,
            channel=channel,
        )

        self.assertIn("<html", message.lower())
        self.assertIn("10 July", message)

    def test_all_locales_have_html_templates(self):

        for locale in User.SUPPORTED_LOCALES:
            for event in self.events:
                template = load_template(locale, event, channel="email")
                self.assertIn("<html", template.lower())

    # --------------------------
    # Dispatch channels
    # --------------------------

    def test_console_channel_dispatch(self):

        user = User("Vaishnavi", "vaish@gmail.com", "en")
        channel = ConsoleChannel()

        message = send_notification(
            user,
            "interview_scheduled",
            self.data,
            channel=channel,
        )
        self.assertIsInstance(message, str)

    def test_email_channel_dry_run_does_not_require_network(self):

        user = User("Vaishnavi", "vaish@gmail.com", "en")
        channel = EmailChannel(dry_run=True)

        result = channel.send(user, "Subject", "Body")
        self.assertTrue(result)

    def test_sms_channel_dry_run_does_not_require_network(self):

        user = User("Vaishnavi", "vaish@gmail.com", "en")
        channel = SMSChannel(dry_run=True)

        result = channel.send(user, "Subject", "Body")
        self.assertTrue(result)


if __name__ == "__main__":
    unittest.main()
