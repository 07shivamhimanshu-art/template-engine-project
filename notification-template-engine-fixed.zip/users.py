import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s: %(message)s"
)


class User:
    """
    Represents a user who receives notifications.
    """

    SUPPORTED_LOCALES = {"en", "hi", "te"}
    DEFAULT_LOCALE = "en"

    def __init__(self, name, email, locale, strict_locale=False):
        """
        Args:
            name: Display name of the user.
            email: Contact email address.
            locale: Preferred language code (e.g. "en", "hi", "te").
            strict_locale: If True, an unsupported locale raises a
                ValueError instead of silently falling back to English.
                Defaults to False to preserve backwards-compatible
                fallback behaviour, but the fallback is now explicit
                and logged instead of happening silently.
        """

        # Validate name
        if not isinstance(name, str) or not name.strip():
            raise ValueError("User name cannot be empty.")

        # Validate email
        if not isinstance(email, str) or "@" not in email:
            raise ValueError("Invalid email address.")

        # Validate locale type
        if not isinstance(locale, str) or not locale.strip():
            raise ValueError("Locale cannot be empty.")

        self.name = name.strip()
        self.email = email.strip()

        locale = locale.strip()

        # Explicit, logged locale validation instead of a silent fallback.
        if locale not in self.SUPPORTED_LOCALES:
            if strict_locale:
                raise ValueError(
                    f"Unsupported locale '{locale}'. "
                    f"Supported locales are: "
                    f"{sorted(self.SUPPORTED_LOCALES)}"
                )

            logging.warning(
                f"Unsupported locale '{locale}' for user '{self.name}'. "
                f"Falling back to default locale "
                f"'{self.DEFAULT_LOCALE}'."
            )
            self.locale = self.DEFAULT_LOCALE
        else:
            self.locale = locale

    def __str__(self):
        return (
            f"User("
            f"name='{self.name}', "
            f"email='{self.email}', "
            f"locale='{self.locale}')"
        )

    def __repr__(self):
        return self.__str__()
